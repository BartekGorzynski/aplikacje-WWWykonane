<?php
session_start();
include('cfg.php');

// Funkcje zarządzania kategoriami
function DodajKategorie($name, $parent_id = 0) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $parent_id);
    return $stmt->execute();
}

function UsunKategorie($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ? OR parent_id = ?");
    $stmt->bind_param("ii", $id, $id);
    return $stmt->execute();
}

function EdytujKategorie($id, $name) {
    global $conn;
    $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    return $stmt->execute();
}

function PokazKategorie($parent_id = 0, $level = 0) {
    global $conn;

    $stmt = $conn->prepare("SELECT id, name FROM categories WHERE parent_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $parent_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;", $level) . htmlspecialchars($row['name']) . " ";
        echo "<a href='?edit={$row['id']}' style='color:blue;'>Edytuj</a> ";
        echo "<a href='?delete={$row['id']}' style='color:red;'>Usuń</a><br>";
        PokazKategorie($row['id'], $level + 1);
    }

    $stmt->close();
}

// Funkcje zarządzania koszykiem
function addToCart($productId, $productName, $priceNet, $vatRate, $quantity) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]['quantity'] += $quantity;
    } else {
        $_SESSION['cart'][$productId] = [
            'name' => $productName,
            'price_net' => $priceNet,
            'vat_rate' => $vatRate,
            'quantity' => $quantity
        ];
    }
}

function removeFromCart($productId) {
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }
}

function updateCart($productId, $quantity) {
    if (isset($_SESSION['cart'][$productId])) {
        if ($quantity > 0) {
            $_SESSION['cart'][$productId]['quantity'] = $quantity;
        } else {
            removeFromCart($productId);
        }
    }
}

function showCart() {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<p>Koszyk jest pusty.</p>";
        return;
    }

    $total = 0;
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr><th>Produkt</th><th>Cena netto</th><th>VAT</th><th>Cena brutto</th><th>Ilość</th><th>Razem</th><th>Akcje</th></tr>";

    foreach ($_SESSION['cart'] as $productId => $product) {
        $priceBrutto = $product['price_net'] * (1 + $product['vat_rate'] / 100);
        $subtotal = $priceBrutto * $product['quantity'];
        $total += $subtotal;

        echo "<tr>";
        echo "<td>" . htmlspecialchars($product['name']) . "</td>";
        echo "<td>" . number_format($product['price_net'], 2) . " PLN</td>";
        echo "<td>" . number_format($product['vat_rate'], 2) . "%</td>";
        echo "<td>" . number_format($priceBrutto, 2) . " PLN</td>";
        echo "<td>" . htmlspecialchars($product['quantity']) . "</td>";
        echo "<td>" . number_format($subtotal, 2) . " PLN</td>";
        echo "<td>";
        echo "<a href='?remove=$productId'>Usuń</a>";
        echo " | ";
        echo "<form method='post' style='display:inline;'>";
        echo "<input type='hidden' name='update_id' value='$productId'>";
        echo "<input type='number' name='update_quantity' value='{$product['quantity']}' min='1'>";
        echo "<button type='submit'>Zmień ilość</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";
    echo "<p><strong>Łączna wartość brutto: " . number_format($total, 2) . " PLN</strong></p>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        $productId = (int)$_POST['product_id'];
        $productName = htmlspecialchars($_POST['product_name']);
        $priceNet = (float)$_POST['price_net'];
        $vatRate = (float)$_POST['vat_rate'];
        $quantity = (int)$_POST['quantity'];

        addToCart($productId, $productName, $priceNet, $vatRate, $quantity);
    }

    if (isset($_POST['update_id'])) {
        $productId = (int)$_POST['update_id'];
        $quantity = (int)$_POST['update_quantity'];

        updateCart($productId, $quantity);
    }
}

if (isset($_GET['remove'])) {
    $productId = (int)$_GET['remove'];
    removeFromCart($productId);
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona dodatkowa</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input, select, button, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .category-list, .product-list {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Dostępne produkty</h2>
    <form method="post">
        <input type="hidden" name="product_id" value="1">
        <input type="hidden" name="product_name" value="Produkt 1">
        <input type="hidden" name="price_net" value="100.00">
        <input type="hidden" name="vat_rate" value="23.00">
        <label>Ilość: </label>
        <input type="number" name="quantity" value="1" min="1">
        <button type="submit" name="add_to_cart">Dodaj do koszyka</button>
    </form>

    <h2>Koszyk</h2>
    <?php showCart(); ?>
</div>
</body>
</html>
