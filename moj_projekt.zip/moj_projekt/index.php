<?php
include('cfg.php');
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

    $strona = 'html/glowna.html';

    if ($_GET['idp'] == 'strona_glowna') $strona = 'html/glowna.html';
    if ($_GET['idp'] == 'kontakt') $strona = 'html/strona_kontaktowa.html';
    if ($_GET['idp'] == 'qingdao') $strona = 'html/Qingdao Haiwan Bridge.html';
    if ($_GET['idp'] == 'manchac') $strona = 'html/Manchac Swamp Bridge.html';
    if ($_GET['idp'] == 'pontchartrain') $strona = 'html/Lake Pontchartrain Causeway.html';
    if ($_GET['idp'] == 'filmy') $strona = 'html/filmy.html';
?>
<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Największe mosty świata</title>
    <link rel="stylesheet" href="css/style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/timedate.js"></script>
  </head>
  <body onload="startclock()">

    <header>
      <h1><b>Najdłuższe mosty na świecie - TOP 3 fascynujących konstrukcji</b></h1>
      <nav>
        <ul class="menu">
          <li><a href="index.php?idp=strona_glowna">Strona główna</a></li>
          <li><a href="index.php?idp=qingdao">Qingdao Haiwan Bridge</a></li>
          <li><a href="index.php?idp=manchac">Manchac Swamp Bridge</a></li>
          <li><a href="index.php?idp=pontchartrain">Lake Pontchartrain Causeway</a></li>
          <li><a href="index.php?idp=filmy">Filmy</a></li>
          <li><a href="index.php?idp=kontakt">Kontakt</a></li>
          <li><a href="admin/admin.php">Admin</a></li>
          <li><a href="sklep.php">Sklep</a></li>
          <li><a href="skrypty.php">Skrypty</a></li>
        </ul>
      </nav>
    </header>
    <section>
      <?php
          if (file_exists($strona)) {
              include($strona);
          } else {
              echo "Podana strona nie istnieje.";
          }
      ?>
    </section>
    <footer>
      <p>Kontakt: <a href="mailto:bartek.gorzynski1209@gmail.com"> MAIL</a></p>
      <?php
          $nr_indeksu = '169242';
          $nrGrupy = '4';
          echo 'Autor: Bartosz Górzyński ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br /><br />';
      ?>
    </footer>
  </body>
</html>
