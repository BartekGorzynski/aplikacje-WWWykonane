<?php
session_start();

$nr_indeksu = '169242';
$nrGrupy = '4';

echo 'Twoje imię: Bartosz Górzyński<br>';
echo 'Numer indeksu: ' . $nr_indeksu . '<br>';
echo 'Grupa: ' . $nrGrupy . '<br><br>';
echo 'Zastosowanie metody include() i require_once()<br><br>';

echo 'Przykład użycia include i require_once:<br>';

include('dodatkowy.php'); 
require_once('dodatkowy.php'); 

echo '<br>';

echo 'Przykład warunków:<br>';

$liczba = 10;

if ($liczba > 10) {
    echo 'Liczba jest większa niż 10<br>';
} elseif ($liczba == 10) {
    echo 'Liczba jest równa 10<br>';
} else {
    echo 'Liczba jest mniejsza niż 10<br>';
}

$kolor = 'czerwony';

switch ($kolor) {
    case 'czerwony':
        echo 'Wybrano kolor czerwony<br>';
        break;
    case 'zielony':
        echo 'Wybrano kolor zielony<br>';
        break;
    default:
        echo 'Wybrano inny kolor<br>';
        break;
}
echo '<br>';

echo 'Przykład pętli while:<br>';
$licznik = 1;
while ($licznik <= 5) {
    echo 'To jest iteracja nr ' . $licznik . '<br>';
    $licznik++;
}

echo '<br>Przykład pętli for:<br>';
for ($i = 1; $i <= 5; $i++) {
    echo 'To jest iteracja nr ' . $i . '<br>';
}
echo '<br>';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['message'] = $_POST['message'];

    echo 'Dziękujemy, ' . $_SESSION['name'] . '! Twoja wiadomość: "' . $_SESSION['message'] . '" została odebrana.<br>';
}

echo 'Przykład użycia $_GET, $_POST i $_SESSION zakończony.<br>';
?>
