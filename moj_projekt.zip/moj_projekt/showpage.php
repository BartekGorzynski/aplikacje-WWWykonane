<?php
// Wyświetlanie konkretnej strony na podstawie ID

include 'cfg.php'; // Wczytanie konfiguracji

// Pobranie ID strony z parametru GET
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    die("Nieprawidłowy identyfikator strony.");
}

// Przygotowanie i wykonanie zapytania
$stmt = $conn->prepare("SELECT page_title, page_content FROM page_list WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h1>" . htmlspecialchars($row['page_title']) . "</h1>";
    echo "<p>" . htmlspecialchars($row['page_content']) . "</p>";
} else {
    echo "<p>Nie znaleziono strony.</p>";
}

// Zamknięcie połączenia
$stmt->close();
ZamknijPolaczenie($conn);
?>
