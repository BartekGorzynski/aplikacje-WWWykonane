<?php
// Include necessary headers and initiate PHP session if required.
session_start();
?>
<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Skrypty Java Script i PHP</title>
    <link rel="stylesheet" href="css/style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/timedate.js"></script>
  </head>
  <body onload="startclock()">
    <header>
      <h1><b>Najdłuższe mosty na świecie - TOP 3 fascynujących konstrukcji</b></h1>
      <nav>
        <ul class="menu">
          <li><a href="index.php?idp=strona_glowna">Strona główna</a></li>
          <li><a href="index.php?idp=qingdao">Qingdao Haiwan Bridge</a></li>
          <li><a href="index.php?idp=manchac">Manchac Swamp Bridge</a></li>
          <li><a href="index.php?idp=pontchartrain">Lake Pontchartrain Causeway</a></li>
          <li><a href="index.php?idp=filmy">Filmy</a></li>
          <li><a href="index.php?idp=kontakt">Kontakt</a></li>
          <li><a href="admin/admin.php">Admin</a></li>
          <li><a href="sklep.php">Sklep</a></li>
          <li><a href="skrypty.php">Skrypty</a></li>
        </ul>
      </nav>
    </header>

    <section>
        <h2>Interaktywne Elementy JavaScript</h2>
        <div>
            Data: <span id="data"></span>
        </div>
        <div>
            Czas: <span id="zegarek"></span>
        </div>
        <div>
            <button onclick="changeBackground('#FFD700')">Zmień tło na żółte</button>
            <button onclick="changeBackground('#ADD8E6')">Zmień tło na niebieskie</button>
        </div>
    </section>

    <section>
        <h2>Dynamiczne Elementy jQuery</h2>
        <div id="animateBlock" style="width:100px; height:100px; background-color:#333; margin:10px;"></div>
        <button id="growOnClick">Powiększ na kliknięcie</button>
    </section>

    <footer>
      <p>Kontakt: <a href="mailto:bartek.gorzynski1209@gmail.com"> MAIL</a></p>
      <?php
          $nr_indeksu = '169242';
          $nrGrupy = '4';
          echo 'Autor: Bartosz Górzyński ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br /><br />';
      ?>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#animateBlock").on("mouseenter", function() {
                $(this).animate({ width: "+=20px", height: "+=20px" }, "fast");
            }).on("mouseleave", function() {
                $(this).animate({ width: "-=20px", height: "-=20px" }, "fast");
            });

            $("#growOnClick").on("click", function() {
                $("#animateBlock").animate({ width: "+=10px", height: "+=10px" }, "fast");
            });
        });

        function changeBackground(hexNumber) {
            document.body.style.backgroundColor = hexNumber;
        }
    </script>
</body>
</html>