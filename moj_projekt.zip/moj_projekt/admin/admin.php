<?php
session_start();
include('../cfg.php');

function FormularzLogowania($error = '') {
    echo '<h2>Logowanie</h2>';
    if ($error) {
        echo "<p style='color:red;'>$error</p>";
    }
    echo '
        <form method="post">
            <label for="login">Login:</label>
            <input type="text" id="login" name="login" required><br>
            <label for="pass">Hasło:</label>
            <input type="password" id="pass" name="pass" required><br>
            <button type="submit" name="loguj">Zaloguj</button>
        </form>
    ';
}


if (isset($_POST['loguj'])) {
    global $login, $pass;
    if ($_POST['login'] === $login && $_POST['pass'] === $pass) {
        $_SESSION['zalogowany'] = true;
        header("Location: admin.php");
        exit;
    } else {
        FormularzLogowania("Nieprawidłowy login lub hasło.");
        exit;
    }
}


if (!isset($_SESSION['zalogowany']) || $_SESSION['zalogowany'] !== true) {
    FormularzLogowania();
    exit;
}


function ListaPodstron($conn) {
    $result = $conn->query("SELECT id, page_title FROM page_list");
    echo '<h2>Lista podstron</h2>';
    echo '<table><tr><th>ID</th><th>Tytuł</th><th>Akcje</th></tr>';
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['page_title']}</td>
                <td>
                    <a href='admin.php?akcja=edytuj&id={$row['id']}'>Edytuj</a> | 
                    <a href='admin.php?akcja=usun&id={$row['id']}'>Usuń</a>
                </td>
              </tr>";
    }
    echo '</table>';
}


function EdytujPodstrone($conn, $id) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $status = isset($_POST['status']) ? 1 : 0;
        $stmt = $conn->prepare("UPDATE page_list SET page_title = ?, page_content = ?, status = ? WHERE id = ?");
        $stmt->bind_param('ssii', $title, $content, $status, $id);
        $stmt->execute();
        header('Location: admin.php');
        exit;
    } else {
        $result = $conn->query("SELECT * FROM page_list WHERE id = $id LIMIT 1");
        $row = $result->fetch_assoc();
        echo '<form method="post">';
        echo '<label for="title">Tytuł:</label><input type="text" name="title" value="' . htmlspecialchars($row['page_title']) . '"><br>';
        echo '<label for="content">Treść:</label><textarea name="content">' . htmlspecialchars($row['page_content']) . '</textarea><br>';
        echo '<label for="status">Aktywna:</label><input type="checkbox" name="status"' . ($row['status'] ? ' checked' : '') . '><br>';
        echo '<button type="submit">Zapisz</button>';
        echo '</form>';
    }
}

function DodajNowaPodstrone($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $status = isset($_POST['status']) ? 1 : 0;

        if (SprawdzPowtorzenia($conn, 'page_list', 'page_title', $title)) {
            echo "<p style='color:red;'>Podstrona o takim tytule już istnieje!</p>";
        } else {
            $stmt = $conn->prepare("INSERT INTO page_list (page_title, page_content, status) VALUES (?, ?, ?)");
            $stmt->bind_param('ssi', $title, $content, $status);
            $stmt->execute();
            header('Location: admin.php');
            exit;
        }
    } else {
        echo '<form method="post">';
        echo '<label for="title">Tytuł:</label><input type="text" name="title"><br>';
        echo '<label for="content">Treść:</label><textarea name="content"></textarea><br>';
        echo '<label for="status">Aktywna:</label><input type="checkbox" name="status"><br>';
        echo '<button type="submit">Dodaj</button>';
        echo '</form>';
    }
}

function UsunPodstrone($conn, $id) {
    $stmt = $conn->prepare("DELETE FROM page_list WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: admin.php');
    exit;
}

if (isset($_GET['akcja'])) {
    $akcja = $_GET['akcja'];
    $id = intval($_GET['id'] ?? 0);
    if ($akcja === 'edytuj' && $id > 0) {
        EdytujPodstrone($conn, $id);
    } elseif ($akcja === 'usun' && $id > 0) {
        UsunPodstrone($conn, $id);
    } elseif ($akcja === 'dodaj') {
        DodajNowaPodstrone($conn);
    }
} else {
    ListaPodstron($conn);
}
?>
