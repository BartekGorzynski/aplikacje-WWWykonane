<?php
session_start();
include('../cfg.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $username = htmlspecialchars($_POST['username']);
        $password = htmlspecialchars($_POST['password']);

        // Sprawdzenie danych logowania
		$stmt = $conn->prepare("SELECT * FROM admin_users WHERE email = ? AND password = ?");
		$stmt->bind_param("ss", $email, $password);
		$stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $_SESSION['logged_in'] = true;
            header('Location: admin_dashboard.php'); // Przekierowanie po zalogowaniu
            exit();
        } else {
            $error = "Nieprawidłowe dane logowania.";
        }
        $stmt->close();
    }

    if (isset($_POST['reset_password'])) {
        $email = htmlspecialchars($_POST['email']);

        // Weryfikacja adresu e-mail
        $stmt = $conn->prepare("SELECT password FROM admin_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $password = $row['password'];

            // Wysłanie wiadomości e-mail
            $to = $email;
            $subject = "Przypomnienie hasła - Panel Admina";
            $message = "Twoje hasło to: $password";
            $headers = "From: admin@example.com";

            if (mail($to, $subject, $message, $headers)) {
                $success = "Wiadomość z hasłem została wysłana.";
            } else {
                $error = "Nie udało się wysłać wiadomości. Spróbuj ponownie.";
            }
        } else {
            $error = "Podany adres e-mail nie istnieje w bazie.";
        }

        $stmt->close();
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie - Panel Admina</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<h2>Logowanie do panelu administracyjnego</h2>
<?php if (isset($error)): ?>
    <p style="color: red;"><?php echo $error; ?></p>
<?php elseif (isset($success)): ?>
    <p style="color: green;"><?php echo $success; ?></p>
<?php endif; ?>
<form method="post" action="admin.php">
    <label for="username">Nazwa użytkownika:</label><br>
    <input type="text" id="username" name="username" required><br><br>

    <label for="password">Hasło:</label><br>
    <input type="password" id="password" name="password" required><br><br>

    <button type="submit" name="login">Zaloguj</button>
</form>

<form method="post" action="admin.php">
    <label for="email">Zapomniałeś hasła? Wprowadź swój e-mail:</label><br>
    <input type="email" id="email" name="email" placeholder="Podaj swój e-mail" required><br><br>

    <button type="submit" name="reset_password">Przypomnij hasło</button>
</form>
</body>
</html>
