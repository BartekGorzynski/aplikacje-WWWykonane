<?php
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

    $strona = 'html/glowna.html';

    if ($_GET['idp'] == 'strona_glowna') $strona = 'html/glowna.html';
    if ($_GET['idp'] == 'kontakt') $strona = 'html/strona_kontaktowa.html';
    if ($_GET['idp'] == 'qingdao') $strona = 'html/Qingdao Haiwan Bridge.html';
    if ($_GET['idp'] == 'manchac') $strona = 'html/Manchac Swamp Bridge.html';
    if ($_GET['idp'] == 'pontchartrain') $strona = 'html/Lake Pontchartrain Causeway.html';
    if ($_GET['idp'] == 'filmy') $strona = 'html/filmy.html';
?>
<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Największe mosty świata</title>
    <link rel="stylesheet" href="css/style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/kolorujtlo.js"></script>
    <script src="js/timedate.js"></script>
  </head>
  <body onload="startclock()">
    <FORM METHOD="POST" NAME="background">
      <INPUT TYPE="button" VALUE="żółty" ONCLICK="changeBackground('#FFF000')">
      <INPUT TYPE="button" VALUE="czarny" ONCLICK="changeBackground('#000000')">
      <INPUT TYPE="button" VALUE="biały" ONCLICK="changeBackground('#FFFFFF')">
      <INPUT TYPE="button" VALUE="zielony" ONCLICK="changeBackground('#00FF00')">
      <INPUT TYPE="button" VALUE="niebieski" ONCLICK="changeBackground('#0000FF')">
      <INPUT TYPE="button" VALUE="pomarańczowy" ONCLICK="changeBackground('#FF8000')">
      <INPUT TYPE="button" VALUE="szary" ONCLICK="changeBackground('#C0C0C0')">
      <INPUT TYPE="button" VALUE="czerwony" ONCLICK="changeBackground('#FF0000')">
    </FORM>
    <header>
      <h1><b>Najdłuższe mosty na świecie - TOP 3 fascynujących konstrukcji</b></h1>
      <nav>
        <ul class="menu">
          <li><a href="index.php?idp=strona_glowna">Strona główna</a></li>
          <li><a href="index.php?idp=qingdao">Qingdao Haiwan Bridge</a></li>
          <li><a href="index.php?idp=manchac">Manchac Swamp Bridge</a></li>
          <li><a href="index.php?idp=pontchartrain">Lake Pontchartrain Causeway</a></li>
          <li><a href="index.php?idp=filmy">Filmy</a></li>
          <li><a href="index.php?idp=kontakt">Kontakt</a></li>
        </ul>
      </nav>
    </header>
    <section>
      <?php
          if (file_exists($strona)) {
              include($strona);
          } else {
              echo "Podana strona nie istnieje.";
          }
      ?>
    </section>
    <footer>
      <p>Kontakt: <a href="mailto:bartek.gorzynski1209@gmail.com"> MAIL</a></p>
      <?php
          $nr_indeksu = '169242';
          $nrGrupy = '4';
          echo 'Autor: Jan Kowalski ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br /><br />';
      ?>
    </footer>
    <script>
      $("#animacjatestowal").on("click", function(){
        $(this).animate({
          width: "500px",
          opacity: 0.4,
          fontSize: "3em",
          borderWidth: "10px"
        }, 1500);
      });
    </script>
    <script>
      $("#animacjaTestowa2").on({
        mouseover: function() {
          $(this).animate({
            width: 300
          }, 800);
        },
        mouseout: function() {
          $(this).animate({
            width: 200
          }, 800);
        }
      });
    </script>
    <script>
      $("#animacjaTestowa3").on("click", function() {
        if (!$(this).is(":animated")) {
          $(this).animate({
            width: "+=50",
            height: "+=10",
            opacity: "+=0.1"
          }, {
            duration: 3000
          });
        }
      });
    </script>
  </body>
</html>
