<?php

function PokazKontakt() {
    echo '<h2>Formularz kontaktowy</h2>';
    echo '
        <form method="post" action="contact.php">
            <label for="temat">Temat:</label><br>
            <input type="text" id="temat" name="temat" required><br>
            
            <label for="tresc">Treść:</label><br>
            <textarea id="tresc" name="tresc" rows="5" required></textarea><br>
            
            <label for="email">Twój email:</label><br>
            <input type="email" id="email" name="email" required><br>
            
            <button type="submit" name="sendMail">Wyślij</button>
        </form>
    ';
}

function wyslijMailaKontakt($odbiorca) {
    if (empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email'])) {
        echo "[nie_wypelniles_pola]";
        echo PokazKontakt();
    } else {
        $mail = [];
        $mail['subject'] = $_POST['temat'];
        $mail['body'] = $_POST['tresc'];
        $mail['sender'] = $_POST['email'];
        $mail['recipient'] = $odbiorca;

        $header = "From: Formularz kontaktowy <" . $mail['sender'] . ">\n";
        $header .= "Reply-To: " . $mail['sender'] . "\n";
        $header .= "MIME-Version: 1.0\n";
        $header .= "Content-Type: text/plain; charset=utf-8\n";
        $header .= "X-Mailer: PHP/" . phpversion() . "\n";
        $header .= "X-Priority: 3\n";
        $header .= "Return-Path: " . $mail['sender'] . "\n";

        mail($mail['recipient'], $mail['subject'], $mail['body'], $header);

        echo "[wiadomosc_wyslana]";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendMail'])) {
    wyslijMailaKontakt("admin@example.com");
} else {
    PokazKontakt();
}
?>
