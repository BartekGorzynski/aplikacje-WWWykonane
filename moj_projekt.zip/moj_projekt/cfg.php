<?php
// Ustawienia bazy danych
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Zmień, jeśli używasz innego użytkownika bazy danych
define('DB_PASS', ''); // Podaj swoje hasło do bazy danych, jeśli jest ustawione
define('DB_NAME', 'moja_strona'); // Upewnij się, że nazwa bazy danych jest poprawna


if (!function_exists('getDatabaseConnection')) {
    function getDatabaseConnection() {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("Błąd połączenia z bazą danych: " . $conn->connect_error);
    }

    return $conn;
    }
}

// Ustawienia SMTP dla wysyłania maili
ini_set('SMTP', 'smtp.gmail.com'); // Podmień na odpowiedni serwer SMTP, jeśli nie używasz Gmaila
ini_set('smtp_port', '587'); // Typowy port SMTP dla szyfrowanego połączenia
ini_set('sendmail_from', 'no-reply@mojprojekt.pl'); // Adres e-mail wysyłający maila

?>