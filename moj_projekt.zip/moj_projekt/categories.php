<?php
include('cfg.php');

// Funkcje zarządzania kategoriami
function DodajKategorie($name, $parent_id = 0) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $parent_id);
    return $stmt->execute();
}

function UsunKategorie($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ? OR parent_id = ?");
    $stmt->bind_param("ii", $id, $id);
    return $stmt->execute();
}

function EdytujKategorie($id, $name) {
    global $conn;
    $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    return $stmt->execute();
}

function PokazKategorie($parent_id = 0, $level = 0) {
    global $conn;

    $stmt = $conn->prepare("SELECT id, name FROM categories WHERE parent_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $parent_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;", $level) . htmlspecialchars($row['name']) . " ";
        echo "<a href='?edit={$row['id']}' style='color:blue;'>Edytuj</a> ";
        echo "<a href='?delete={$row['id']}' style='color:red;'>Usuń</a><br>";
        PokazKategorie($row['id'], $level + 1);
    }

    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_category'])) {
        $name = htmlspecialchars($_POST['name']);
        $parent_id = (int) $_POST['parent_id'];
        DodajKategorie($name, $parent_id);
    } elseif (isset($_POST['edit_category'])) {
        $id = (int) $_POST['id'];
        $name = htmlspecialchars($_POST['name']);
        EdytujKategorie($id, $name);
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    UsunKategorie($id);
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zarządzanie kategoriami</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .category-list {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Zarządzanie kategoriami</h2>

    <?php if (isset($_GET['edit'])): ?>
        <?php
        $id = (int) $_GET['edit'];
        $stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $category = $result->fetch_assoc();
        ?>
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label for="name">Edytuj nazwę kategorii:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
            <button type="submit" name="edit_category">Zapisz zmiany</button>
        </form>
    <?php else: ?>
        <form method="post" action="">
            <label for="name">Nazwa kategorii:</label>
            <input type="text" id="name" name="name" required>

            <label for="parent_id">Kategoria nadrzędna:</label>
            <select id="parent_id" name="parent_id">
                <option value="0">Brak (kategoria główna)</option>
                <?php
                $result = $conn->query("SELECT id, name FROM categories WHERE parent_id = 0 ORDER BY name ASC");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['name']}</option>";
                }
                ?>
            </select>

            <button type="submit" name="add_category">Dodaj kategorię</button>
        </form>
    <?php endif; ?>

    <div class="category-list">
        <h3>Lista kategorii:</h3>
        <?php PokazKategorie(); ?>
    </div>
</div>
</body>
</html>
