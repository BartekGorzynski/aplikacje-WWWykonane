<?php
// Dane logowania do panelu administracyjnego
$login = 'admin'; // Ustaw swój login
$pass = 'haslo';  // Ustaw swoje hasło

// Konfiguracja połączenia z bazą danych
$host = '127.0.0.1';  // Adres serwera MySQL (localhost lub 127.0.0.1)
$user = 'root';       // Domyślny użytkownik MySQL w XAMPP
$password = '';       // Hasło do MySQL w XAMPP domyślnie jest puste
$dbname = 'moja_strona'; // Nazwa bazy danych
$port = 3306;         // Port MySQL (domyślnie 3306, w XAMPP czasami 3307)

// Połączenie z bazą danych
$conn = new mysqli($host, $user, $password, $dbname, $port);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

function SprawdzPowtorzenia($conn, $table, $column, $value) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM $table WHERE $column = ?");
    $stmt->bind_param("s", $value);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    // Zwróć true, jeśli istnieje już wpis z tą wartością
    return $count > 0;
}
?>
