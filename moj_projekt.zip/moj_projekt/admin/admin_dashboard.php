<?php
include('../cfg.php');

// Funkcje zarządzania kategoriami
function DodajKategorie($name, $parent_id = 0) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $parent_id);
    return $stmt->execute();
}

function UsunKategorie($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ? OR parent_id = ?");
    $stmt->bind_param("ii", $id, $id);
    return $stmt->execute();
}

function EdytujKategorie($id, $name) {
    global $conn;
    $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    return $stmt->execute();
}

function PokazKategorie($parent_id = 0, $level = 0) {
    global $conn;

    $stmt = $conn->prepare("SELECT id, name FROM categories WHERE parent_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $parent_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;", $level) . htmlspecialchars($row['name']) . " ";
        echo "<a href='?edit={$row['id']}' style='color:blue;'>Edytuj</a> ";
        echo "<a href='?delete={$row['id']}' style='color:red;'>Usuń</a><br>";
        PokazKategorie($row['id'], $level + 1);
    }

    $stmt->close();
}

// Funkcje zarządzania produktami
function DodajProdukt($title, $description, $expiration_date, $price_net, $vat_rate, $quantity, $availability_status, $category_id, $dimensions, $image_path) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO products (title, description, expiration_date, price_net, vat_rate, quantity, availability_status, category_id, dimensions, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddiisds", $title, $description, $expiration_date, $price_net, $vat_rate, $quantity, $availability_status, $category_id, $dimensions, $image_path);
    return $stmt->execute();
}

function UsunProdukt($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

function EdytujProdukt($id, $title, $description, $expiration_date, $price_net, $vat_rate, $quantity, $availability_status, $category_id, $dimensions, $image_path) {
    global $conn;
    $stmt = $conn->prepare("UPDATE products SET title = ?, description = ?, expiration_date = ?, price_net = ?, vat_rate = ?, quantity = ?, availability_status = ?, category_id = ?, dimensions = ?, image_path = ? WHERE id = ?");
    $stmt->bind_param("sssddiisds", $title, $description, $expiration_date, $price_net, $vat_rate, $quantity, $availability_status, $category_id, $dimensions, $image_path, $id);
    return $stmt->execute();
}

function PokazProdukty() {
    global $conn;
    $result = $conn->query("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
        echo "<p>Kategoria: " . htmlspecialchars($row['category_name'] ?? "Brak") . "</p>";
        echo "<p>Opis: " . htmlspecialchars($row['description']) . "</p>";
        echo "<p>Cena netto: " . number_format($row['price_net'], 2) . " PLN</p>";
        echo "<p>VAT: " . number_format($row['vat_rate'], 2) . "%</p>";
        echo "<p>Ilość: " . htmlspecialchars($row['quantity']) . "</p>";
        echo "<p>Status: " . ($row['availability_status'] ? "Dostępny" : "Niedostępny") . "</p>";
        echo "<p>Data ważności: " . htmlspecialchars($row['expiration_date']) . "</p>";
        echo "<p><a href='?edit_product=" . $row['id'] . "'>Edytuj</a> | <a href='?delete_product=" . $row['id'] . "' style='color:red;'>Usuń</a></p>";
        echo "</div><hr>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_category'])) {
        $name = htmlspecialchars($_POST['name']);
        $parent_id = (int) $_POST['parent_id'];
        DodajKategorie($name, $parent_id);
    } elseif (isset($_POST['edit_category'])) {
        $id = (int) $_POST['id'];
        $name = htmlspecialchars($_POST['name']);
        EdytujKategorie($id, $name);
    } elseif (isset($_POST['add_product'])) {
        $title = htmlspecialchars($_POST['title']);
        $description = htmlspecialchars($_POST['description']);
        $expiration_date = $_POST['expiration_date'];
        $price_net = (float) $_POST['price_net'];
        $vat_rate = (float) $_POST['vat_rate'];
        $quantity = (int) $_POST['quantity'];
        $availability_status = isset($_POST['availability_status']) ? 1 : 0;
        $category_id = (int) $_POST['category_id'];
        $dimensions = htmlspecialchars($_POST['dimensions']);
        $image_path = htmlspecialchars($_POST['image_path']);
        DodajProdukt($title, $description, $expiration_date, $price_net, $vat_rate, $quantity, $availability_status, $category_id, $dimensions, $image_path);
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    UsunKategorie($id);
}

if (isset($_GET['delete_product'])) {
    $id = (int) $_GET['delete_product'];
    UsunProdukt($id);
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel zarządzania</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input, select, button, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .category-list, .product-list {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Zarządzanie kategoriami</h2>

    <?php if (isset($_GET['edit'])): ?>
        <?php
        $id = (int) $_GET['edit'];
        $stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $category = $result->fetch_assoc();
        ?>
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label for="name">Edytuj nazwę kategorii:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
            <button type="submit" name="edit_category">Zapisz zmiany</button>
        </form>
    <?php else: ?>
        <form method="post" action="">
            <label for="name">Nazwa kategorii:</label>
            <input type="text" id="name" name="name" required>

            <label for="parent_id">Kategoria nadrzędna:</label>
            <select id="parent_id" name="parent_id">
                <option value="0">Brak (kategoria główna)</option>
                <?php
                $result = $conn->query("SELECT id, name FROM categories WHERE parent_id = 0 ORDER BY name ASC");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['name']}</option>";
                }
                ?>
            </select>

            <button type="submit" name="add_category">Dodaj kategorię</button>
        </form>
    <?php endif; ?>

    <div class="category-list">
        <h3>Lista kategorii:</h3>
        <?php PokazKategorie(); ?>
    </div>

    <h2>Zarządzanie produktami</h2>
    <?php if (isset($_GET['edit_product'])): ?>
        <?php
        $id = (int)$_GET['edit_product'];
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();
        ?>
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($product['title']); ?>" required>
            <label for="description">Opis:</label>
            <textarea name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
            <!-- Dodaj inne pola dla produktu -->
            <button type="submit" name="edit_product">Zapisz zmiany</button>
        </form>
    <?php else: ?>
        <form method="post" action="">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" required>
            <label for="description">Opis:</label>
            <textarea name="description" required></textarea>
            <label for="price_net">Cena netto:</label>
            <input type="number" step="0.01" name="price_net" required>
            <label for="vat_rate">VAT (%):</label>
            <input type="number" step="0.01" name="vat_rate" required>
            <label for="quantity">Ilość:</label>
            <input type="number" name="quantity" required>
            <label for="availability_status">Dostępność:</label>
            <select name="availability_status">
                <option value="1">Dostępny</option>
                <option value="0">Niedostępny</option>
            </select>
            <label for="category_id">Kategoria:</label>
            <select name="category_id">
                <option value="0">Brak</option>
                <?php
                $result = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['name']}</option>";
                }
                ?>
            </select>
            <label for="dimensions">Wymiary (opcjonalne):</label>
            <input type="text" name="dimensions">
            <label for="image_path">Ścieżka do obrazka (opcjonalne):</label>
            <input type="text" name="image_path">
            <button type="submit" name="add_product">Dodaj produkt</button>
        </form>
    <?php endif; ?>

    <div class="product-list">
        <h3>Lista produktów:</h3>
        <?php PokazProdukty(); ?>
    </div>
</div>
</body>
</html>
