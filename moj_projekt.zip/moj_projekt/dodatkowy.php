<?php
echo 'To jest zawartość pliku dodatkowy.php<br>';
?>
