<?php
include('cfg.php');


if (!isset($conn) || $conn === null) {
    die("Połączenie z bazą danych nie zostało ustanowione.");
}

$id = intval($_GET['idp'] ?? 1);

$stmt = $conn->prepare("SELECT page_title, page_content FROM page_list WHERE id = ?");
if ($stmt === false) {
    die("Błąd przygotowania zapytania: " . $conn->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h1>" . htmlspecialchars($row['page_title']) . "</h1>";
    echo "<p>" . htmlspecialchars($row['page_content']) . "</p>";
} else {
    echo "<h1>Nie znaleziono strony.</h1>";
}
?>
